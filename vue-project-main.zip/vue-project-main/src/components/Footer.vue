<template>
  <div class="p-5">
    <footer>
        <div class="row">
            <div class="col-md-5 text-end">
                <h2>Luxury Jewelry</h2>
                <p>make with love</p>
            </div> 
            <div class="col-md-4 text-center">
                <ul>
                    <li><a href="" class="text-decoration-none fs-5 text-dark">Ring</a></li>
                    <li><a href="" class="text-decoration-none fs-5 text-dark">Bracelet</a></li>
                    <li><a href="" class="text-decoration-none fs-5 text-dark">Necklace</a></li>
                    <li><a href="" class="text-decoration-none fs-5 text-dark">Crown</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <ul>
                    <li><a href="" class="text-decoration-none fs-5 text-dark">About Us</a></li>
                    <li><a href="" class="text-decoration-none fs-5 text-dark">Store</a></li>
                </ul>
            </div>
    
            <div class="col-md-12 text-center mars">
                <h2>Luxury Jewelry</h2>
            </div>
    
        </div>
    </footer>
</div>
</template>

<style scoped>
 ul{
   list-style: none;
 }

a{
    font-family: 'Londrina Solid', cursive;
}

.mars{
   margin-top: 70px;
}

p{
    font-family: 'Mukta Mahee', sans-serif;
}
 
h2{
    font-family: 'Nanum Myeongjo', serif;
    font-weight: bold;
}
</style>

